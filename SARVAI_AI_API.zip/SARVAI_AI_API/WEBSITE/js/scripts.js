document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Login form submitted!');
});

document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Signup form submitted!');
});
